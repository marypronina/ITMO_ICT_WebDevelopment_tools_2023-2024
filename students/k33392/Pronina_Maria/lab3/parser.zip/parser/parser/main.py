import time
import threading
from typing import List
from parser import get_github_user_info as parse
from models import User, UserProject
from connection import get_session, init_db
from sqlalchemy.future import select
from fastapi import FastAPI, HTTPException
from celery import shared_task
import requests


def parse_and_save(usernames, session):
    for username in usernames:
        data = parse(username)
        if data:
            user_prefs = ', '.join(str(pref) for pref in data['unique_languages'])
            save_user(username, data['name'], data['bio'], user_prefs, session)

            projects = data['pinned_repos']
            query = select(User).where(User.name == data['name'])
            user_id = session.exec(query).scalar().id
            save_projects(projects, user_id, session)


def save_user(username, name, about, preferences, session):
    print(f'User: \nName: {name} \nAbout: {about} \nPreferences: {preferences}')
    user = User(name=name, about=about, preferences=preferences, email=username, password='secret')

    print(user)
    session.add(user)
    session.commit()


def save_projects(projects, user_id, session):
    for project in projects:
        cur_project = UserProject(user_id=user_id, name=project['repo_name'], description=project['about'], in_search=False)
        print(f'Project: \nUser: {user_id} \nName: {project["repo_name"]} \nDescription: {project["about"]}')

        session.add(cur_project)
        session.commit()


@shared_task
def parse_task(usernames: List[str]) -> str:
    session = next(get_session())

    parse_and_save(usernames, session)

    return "Usernames parsed successfully"


app = FastAPI()


@app.post('/parse')
async def parse(usernames: List[str]) -> str:
    try:
        parse_task.delay(usernames)
        return {"message": "Parsing task started"}
    except requests.RequestException as err:
        raise HTTPException(status_code=500, detail=str(err))
